//
// Created by Leonardo on 30/03/2022.
//

#include "ELBO.h"

double elbo_calculator(const Eigen::MatrixXd& Y_tot, VariationalParameters & vb_data, const AlgorithmParameters & alg_par,
                       std::vector<double>& elbo_prec) {
    double elbo = 0;

    unsigned M = alg_par.M;
    unsigned J = alg_par.J;
    unsigned T = alg_par.T;
    unsigned p = alg_par.p;

    double gamma = alg_par.gamma;

    double eta_bar = vb_data.eta_k.sum();

    Eigen::VectorXd diga_a = vb_data.a_k_beta.array().digamma();
    Eigen::VectorXd diga_b = vb_data.b_k_beta.array().digamma();
    Eigen::VectorXd diga_ab = (vb_data.a_k_beta + vb_data.b_k_beta).array().digamma();
    double diga_e_b = Eigen::numext::digamma(eta_bar);
    Eigen::VectorXd diga_eta = vb_data.eta_k.array().digamma();

    Eigen::VectorXd nu_sum_MIX = Eigen::VectorXd::Zero(J);
    Eigen::VectorXd nu_sum_DP = Eigen::VectorXd::Zero(T);

    for(unsigned i = 1; i <= p; i++) {
        nu_sum_MIX += ((vb_data.nu_VAR_MIX.array() - double(i) + 1.) * 0.5).digamma().matrix();
        nu_sum_DP += ((vb_data.nu_var_DP.array() - double(i) + 1.) * 0.5).digamma().matrix();
    }

    double f1 = 0;
    double f2 = 0;
    double f3 = 0;
    double f4 = 0;
    double f5 = 0;
    double f6 = 0;
    double f7 = 0;
    double f8 = 0;

    double h1 = 0;
    double h2 = 0;
    double h3 = 0;
    double h4 = 0;
    double h5 = 0;

    /* Expected value of log(p) */

    for(unsigned k = 0; k < J; k++) {
        f1 += E_log_norm(vb_data.Phi_m_k.col(k),
                         Y_tot,
                         vb_data.mu_VAR_MIX.col(k),
                         vb_data.nu_VAR_MIX(k),
                         vb_data.lambda_VAR_MIX(k),
                         vb_data.PSI_VAR_MIX_inv[k],
                         double(p), nu_sum_MIX(k), M);
    }

    for(unsigned k = 0; k < T; k++) {
        f2 += E_log_norm(vb_data.Phi_m_k.col(k+J),
                         Y_tot,
                         vb_data.mu_var_DP.col(k),
                         vb_data.nu_var_DP(k),
                         vb_data.lambda_var_DP(k),
                         vb_data.PSI_var_DP_inv[k],
                         double(p), nu_sum_DP(k), M);
    }

    elbo_prec[0] = f1;
    elbo_prec[1] = f2;

    for(unsigned k = 0; k < J; k++) {
        f3 += E_log_norm_inv_wish(vb_data.mu_VAR_MIX.col(k),
                                  vb_data.nu_VAR_MIX(k),
                                  vb_data.lambda_VAR_MIX(k),
                                  vb_data.PSI_VAR_MIX_inv[k],
                                  alg_par.mu_0_MIX.col(k),
                                  alg_par.nu_0_MIX(k),
                                  alg_par.lambda_0_MIX(k),
                                  alg_par.PSI_0_MIX[k],
                                  double(p), nu_sum_MIX(k));
    }

    for(unsigned k = 0; k < T; k++) {
        f4 += E_log_norm_inv_wish(vb_data.mu_var_DP.col(k),
                                  vb_data.nu_var_DP(k),
                                  vb_data.lambda_var_DP(k),
                                  vb_data.PSI_var_DP_inv[k],
                                  alg_par.mu_0_DP,
                                  alg_par.nu_0_DP,
                                  alg_par.lambda_0_DP,
                                  alg_par.PSI_0_DP,
                                  double(p), nu_sum_DP(k));
    }

    elbo_prec[2] = f3;
    elbo_prec[3] = f4;

    f5 = f5_calculator(vb_data.Phi_m_k, diga_eta, diga_e_b, J);
    elbo_prec[4] = f5;

    f6 += f6_calculator(vb_data.Phi_m_k, diga_a, diga_ab, diga_b, diga_eta(0), diga_e_b, J, T);
    elbo_prec[5] = f6;

    f7 = f7_calculator(diga_eta, alg_par.a_dir_k, diga_e_b);
    elbo_prec[6] = f7;

    f8 = f8_calculator(diga_b, diga_ab, gamma);
    elbo_prec[7] = f8;

    /* Expected value of log(q) */

    h1 = h1_calculator(vb_data.Phi_m_k);
    elbo_prec[8] = h1;

    h2 = h2_calculator(vb_data.eta_k, diga_eta, diga_e_b);
    elbo_prec[9] = h2;

    h3 = h3_calculator(vb_data.a_k_beta, vb_data.b_k_beta, diga_a, diga_b, diga_ab);
    elbo_prec[10] = h3;

    for(unsigned i = 0; i < J; i++)
        h4 += E_log_dens_norm_inv_wish_q(vb_data.nu_VAR_MIX(i),
                                         vb_data.lambda_VAR_MIX(i),
                                         vb_data.PSI_VAR_MIX_inv[i],
                                         double(p), nu_sum_MIX(i));
    elbo_prec[11] = h4;
    for(unsigned i = 0; i < T; i++)
        h5 += E_log_dens_norm_inv_wish_q(vb_data.nu_var_DP(i),
                                         vb_data.lambda_var_DP(i),
                                         vb_data.PSI_var_DP_inv[i],
                                         double(p), nu_sum_DP(i));
    elbo_prec[12] = h5;


    elbo = f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 - ( h1 + h2 + h3 + h4 + h5 );
    return elbo;
}
