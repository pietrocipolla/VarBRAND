// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppEigen.h which pulls Rcpp.h in for us
#include <RcppEigen.h>
#include "iostream"
#include "VBData.h"
#include "Cavi.h"

// via the depends attribute we tell Rcpp to create hooks for
// RcppEigen so that the build process will know what to do
//
// [[Rcpp::depends(RcppEigen)]]


// [[Rcpp::export]]
Rcpp::List VarBrand(const Eigen::MatrixXd & Y_tot,
                              const  int p,
                               const  int J,
                               const  int T,
                               const  int n_iter,
                               const double tol,
                               const  int gamma,

                              const  Eigen::VectorXd & a_dir_k,

                              const  Eigen::VectorXd & mu_0_DP,
                              const  double nu_0_DP,
                              const  double lambda_0_DP,
                              const  Eigen::MatrixXd & PSI_0_DP,

                              const  Eigen::MatrixXd & mu_0_MIX,
                              const  Eigen::VectorXd & nu_0_MIX,
                              const  Eigen::VectorXd & lambda_0_MIX,
                              const  std::vector<Eigen::MatrixXd> & PSI_0_MIX,

                              const unsigned int M,
                              const  Eigen::MatrixXd & Phi_m_k,
                              const  Eigen::VectorXd & eta_k,
                              const  Eigen::VectorXd & a_k_beta,
                              const  Eigen::VectorXd & b_k_beta,

                              const  Eigen::MatrixXd & mu_var_DP,
                              const  Eigen::VectorXd & nu_var_DP,
                              const  Eigen::VectorXd & lambda_var_DP,
                              const  std::vector<Eigen::MatrixXd> & PSI_var_DP,

                              const  Eigen::MatrixXd& mu_VAR_MIX,
                              const  Eigen::VectorXd& nu_VAR_MIX,
                              const  Eigen::VectorXd& lambda_VAR_MIX,
                              const  std::vector<Eigen::MatrixXd> & PSI_VAR_MIX
                               ) {

    std::vector<Eigen::MatrixXd> PSI_var_DP_inv = PSI_var_DP;
    for(unsigned i = 0; i < PSI_var_DP_inv.size(); i++){
        PSI_var_DP_inv[i] = PSI_var_DP_inv[i].inverse();
    }
    std::vector<Eigen::MatrixXd> PSI_VAR_MIX_inv = PSI_VAR_MIX;
    for(unsigned i = 0; i < PSI_VAR_MIX_inv.size(); i++){
        PSI_VAR_MIX_inv[i] = PSI_VAR_MIX_inv[i].inverse();
    }

    VariationalParameters vb_data = VariationalParameters (
            Phi_m_k,
            eta_k,
            a_k_beta,
            b_k_beta,

            mu_var_DP,
            nu_var_DP,
            lambda_var_DP,
            PSI_var_DP_inv,

            mu_VAR_MIX,
            nu_VAR_MIX,
            lambda_VAR_MIX,
            PSI_VAR_MIX_inv);


    AlgorithmParameters alg_par = AlgorithmParameters(
        p,
        J,
        T,

        n_iter,
        tol,
        gamma,

        a_dir_k,

        mu_0_DP,
        nu_0_DP,
        lambda_0_DP,
        PSI_0_DP,

        mu_0_MIX,
        nu_0_MIX,
        lambda_0_MIX,
        PSI_0_MIX,

        M
    );

    Cavi cavi = Cavi(Y_tot, vb_data, alg_par);

//    std::vector<double> elbo_values;
//    elbo_values.push_back(1.0);
    std::vector<double> elbo_values = cavi.start();

//    for (unsigned i = 0; i < elbo_values.size(); i++)
//        std::cout << elbo_values[i] << " ";

    return Rcpp::List::create(Rcpp::Named("Phi_m_k")=vb_data.Phi_m_k,
                              Rcpp::Named("mu_VAR_MIX")=vb_data.mu_VAR_MIX,
                              Rcpp::Named("mu_var_DP")=vb_data.mu_var_DP,
                              Rcpp::Named("elbo_values")=elbo_values);

}

