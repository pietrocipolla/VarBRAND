//
// Created by Leonardo on 31/03/2022.
//

#ifndef VBDATA_H_ELBO_FUNCTIONS_H
#define VBDATA_H_ELBO_FUNCTIONS_H

#include "Cavi.h"
#include "VBData.h"

#include <iostream>
#include <vector>
#include <tuple>

#include "root/lib/eigen-3.4.0/Eigen/Core"
#include "root/lib/eigen-3.4.0/Eigen/Dense"
#include "root/lib/eigen-3.4.0/Eigen/LU"
#include "root/lib/eigen-3.4.0/unsupported/Eigen/SpecialFunctions"

double E_log_norm(const Eigen::VectorXd&,
                  const Eigen::MatrixXd&,
                  const Eigen::VectorXd&,
                  double, double,
                  const Eigen::MatrixXd&,
                  double, double,
                  unsigned);

double E_log_norm_inv_wish(const Eigen::VectorXd&,
                           double, double,
                           const Eigen::MatrixXd&,
                           const Eigen::VectorXd&,
                           double, double,
                           const Eigen::MatrixXd&,
                           double, double);

double f5_calculator(const Eigen::MatrixXd&,
                     const Eigen::VectorXd&,
                     const double,
                     const unsigned);

double f6_calculator(const Eigen::MatrixXd&,
                     const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     double, double,
                     unsigned, unsigned);

double f7_calculator(const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     double);

double f8_calculator(const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     double);

double h1_calculator(const Eigen::MatrixXd&);

double h2_calculator(const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     double);

double h3_calculator(const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     const Eigen::VectorXd&,
                     const Eigen::VectorXd&);

double E_log_dens_norm_inv_wish_q(double, double,
                                  const Eigen::MatrixXd&,
                                  double, double);

double multivariate_gamma(double, double);

#endif //VBDATA_H_ELBO_FUNCTIONS_H
