//
// Created by Leonardo on 31/03/2022.
//

#include "ELBO_functions.h"

double E_log_norm(const Eigen::VectorXd& phi_m,
                  const Eigen::MatrixXd& Y_tot,
                  const Eigen::VectorXd& mu,
                  const double nu,
                  const double lambda,
                  const Eigen::MatrixXd& invPSI,
                  const double p, const double nu_sum,
                  unsigned M) {

    Eigen::VectorXd matxvec_temp;
    Eigen::VectorXd Y_centered;

    double det_inv_psi = invPSI.determinant();
    double comp1 = 0.;
    double comp2 = 0.;
    double ret = 0.;

    if(det_inv_psi != 0)
        comp1 = -nu_sum - std::log(det_inv_psi) + p/lambda; // - p*std::log(M_PI);
    else
        comp1 = -nu_sum + p/lambda; // - p*std::log(M_PI);

    for(unsigned i = 0; i < M; i++) {
        Y_centered = Y_tot.row(i).transpose() - mu;
        matxvec_temp =  invPSI * Y_centered;
        comp2 = nu * Y_centered.transpose()*matxvec_temp;

        ret += phi_m(i)*(-0.5)*(comp1 + comp2);
    }

    return ret;
}

/*double E_log_norm_inv_wish(const Eigen::VectorXd& mu_var,
                           double nu_var, double lam_var,
                           const Eigen::MatrixXd& invPSI,
                           const Eigen::VectorXd& mu0,
                           double nu0, double lam0,
                           const Eigen::MatrixXd& PSI0,
                           double p, double nu_sum) {
    Eigen::VectorXd matxvec_temp;
    Eigen::VectorXd mu_centered;

    double comp1 = 0.;
    double comp2 = 0.;
    double comp3 = 0.;
    double ret = 0.;

    comp1 -= p*lam0/lam_var*(std::log(invPSI.determinant()) + nu_sum);

    mu_centered = mu_var - mu0;
    matxvec_temp =  invPSI * mu_centered;
    comp2 = (mu_centered.transpose() * matxvec_temp);
    comp2 = lam0*nu_var*comp2;

    comp3 += nu_var*(PSI0*invPSI).trace();

    ret = -0.5*(comp1 + comp2 + comp3);

    return ret;
}*/

double E_log_norm_inv_wish(const Eigen::VectorXd& mu_var,
                           double nu_var, double lam_var,
                           const Eigen::MatrixXd& invPSI,
                           const Eigen::VectorXd& mu0,
                           double nu0, double lam0,
                           const Eigen::MatrixXd& PSI0,
                           double p, double nu_sum) {
    Eigen::VectorXd matxvec_temp;
    Eigen::VectorXd mu_centered;

    double comp1 = 0.;
    double comp2 = 0.;
    double comp3 = 0.;
    double comp4 = 0.;
    double ret = 0.;

    comp1 = std::log(invPSI.determinant()) + nu_sum;
    comp1 = (nu0+p+2)*(comp1);
    comp1 = 0.5*comp1;

    comp2 = -0.5*p*lam0/lam_var;

    mu_centered = mu_var - mu0;
    matxvec_temp =  invPSI * mu_centered;
    comp3 = mu_centered.transpose() * matxvec_temp;
    comp3 = -0.5*lam0*nu_var*comp3;

    comp4 = (PSI0*invPSI).trace();
    comp4 = -0.5*nu_var*comp4;

    ret = comp1 + comp2 + comp3 + comp4;

    return ret;
}

double f5_calculator(const Eigen::MatrixXd& Phi_m_k,
                     const Eigen::VectorXd& diga_eta,
                     double diga_e_b, unsigned J) {
     Eigen::VectorXd temp = diga_eta.bottomRows(J).array() - diga_e_b;

    /*
     Eigen::VectorXd temp(J);

    for(unsigned i = 0; i < J; i++){
        temp(i) = diga_eta(i+1) - diga_e_b;
    }
    */
    return (Phi_m_k.leftCols(J) * temp).sum();
}

double f6_calculator(const Eigen::MatrixXd& Phi_m_k,
                     const Eigen::VectorXd& diga_a,
                     const Eigen::VectorXd& diga_ab,
                     const Eigen::VectorXd& diga_b,
                     double diga_eta0, double diga_e_b,
                     unsigned J, unsigned T) {
    double ret = 0.;
    double comp1 = 0.;
    double comp2 = 0.;
    double comp3 = 0.;

    comp1 = diga_eta0 - diga_e_b;
    for(unsigned k = 0; k < (T-1); k++){
        comp2 = diga_a(k) - diga_ab(k);
        if(k > 0)
            comp3 += diga_b(k-1) - diga_ab(k-1);
        ret += Phi_m_k.col(k+J).sum()*(comp1 + comp2 + comp3);
    }

    //last cluster
    comp2 = 0;
    comp3 += diga_b(T-2) - diga_ab(T-2);
    ret += Phi_m_k.col(T+J-1).sum()*(comp1 + comp2 + comp3);
    return ret;
}

double f7_calculator(const Eigen::VectorXd& diga_eta,
                     const Eigen::VectorXd& a_k,
                     double diga_e_b) {
    Eigen::VectorXd temp = diga_eta.array() - diga_e_b;
    Eigen::VectorXd temp2 = a_k.array() - 1;

    return temp.transpose() * temp2;
}

double f8_calculator(const Eigen::VectorXd& diga_b,
                     const Eigen::VectorXd& diga_ab,
                     double gamma) {
    return (gamma - 1)*(diga_b - diga_ab).sum();
}

double h1_calculator(const Eigen::MatrixXd& Phi_m_k) {
    // return (Eigen::log(Phi_m_k.array().pow(Phi_m_k.array())).sum());
    double ret = 0.;

    for(unsigned i = 0; i < Phi_m_k.rows(); i++){
        for(unsigned j = 0; j < Phi_m_k.cols(); j++){
            ret += std::log(pow(Phi_m_k(i, j),Phi_m_k(i, j)));
        }
    }
    return ret;
}

double h2_calculator(const Eigen::VectorXd& eta_k,
                     const Eigen::VectorXd& diga_eta,
                     double diga_e_b) {
    double comp1 = 0;
    double comp2 = 0;
    double comp3 = 0;

    comp1 = (eta_k.array() - 1).matrix().dot((diga_eta.array() - diga_e_b).matrix());
    comp2 = lgamma(eta_k.sum());
    comp3 = -(eta_k.array().lgamma()).sum();

    return comp1 + comp2 + comp3;
}

double h3_calculator(const Eigen::VectorXd& a_k_beta,
                     const Eigen::VectorXd& b_k_beta,
                     const Eigen::VectorXd& diga_a,
                     const Eigen::VectorXd& diga_b,
                     const Eigen::VectorXd& diga_ab) {
    double comp1 = 0;
    double comp2 = 0;
    double comp3 = 0;

    comp1 = (a_k_beta.array() - 1).matrix().dot(diga_a - diga_ab);
    comp2 = (b_k_beta.array() - 1).matrix().dot(diga_b - diga_ab);
    comp3 = - (a_k_beta.array().lgamma() + b_k_beta.array().lgamma() - (a_k_beta + b_k_beta).array().lgamma()).sum();
    /* unsigned l = a_k_beta.rows();
    for(unsigned i = 0; i<l;i++){
        comp3 -= Eigen::numext::lgamma(a_k_beta(i)) + Eigen::numext::lgamma(b_k_beta(i)) - Eigen::numext::lgamma(a_k_beta(i) + b_k_beta(i));
    } */
    return comp1 + comp2 + comp3;
};

double E_log_dens_norm_inv_wish_q(double nu, double lam,
                                  const Eigen::MatrixXd& PSI_inv,
                                  double p,
                                  double nu_sum) {
    double comp1 = 0;
    double comp2 = 0;
    double comp3 = 0;
    double comp4 = 0;
    double comp5 = 0;
    double comp6 = 0;

    double log_det = -std::log(PSI_inv.determinant());

    comp1 = 0.5*nu*log_det;
    comp2 = -nu*p*0.5*std::log(2);
    comp3 = -multivariate_gamma(p,nu/2);
    comp4 = 0.5*p*std::log(lam);
    comp5 = ((nu+p+2)/2)*(-log_det + nu_sum);
    comp6 = -0.5*p*nu;

    return comp1 + comp2 + comp3 + comp4 + comp5 + comp6;
};

double multivariate_gamma(double p, double a) {
    if (p==1) {
        return Eigen::numext::lgamma(a);
    }
    else {
        // Non sommo log(M_PI)*(p-1)/2 perche' costante additiva
        return Eigen::numext::lgamma(a+(1-p)/2.0) + multivariate_gamma(p-1,a);
    }
};
