//#include <RcppEigen.h>
#include <iostream>
#include <vector>

#include "root/lib/eigen-3.4.0/Eigen/Core"
#include "root/lib/eigen-3.4.0/Eigen/Dense"
#pragma once

struct VariationalParameters {
  public:
    Eigen::MatrixXd Phi_m_k;
    Eigen::VectorXd eta_k;
    Eigen::VectorXd a_k_beta;
    Eigen::VectorXd b_k_beta;
    
    Eigen::MatrixXd mu_var_DP;
    Eigen::VectorXd nu_var_DP;
    Eigen::VectorXd lambda_var_DP;
    std::vector<Eigen::MatrixXd> PSI_var_DP_inv;
    
    Eigen::MatrixXd mu_VAR_MIX;
    Eigen::VectorXd nu_VAR_MIX;
    Eigen::VectorXd lambda_VAR_MIX;
    std::vector<Eigen::MatrixXd> PSI_VAR_MIX_inv;
    
    VariationalParameters (
            Eigen::MatrixXd  Phi_m_k,
            Eigen::VectorXd  eta_k,
            Eigen::VectorXd  a_k_beta,
            Eigen::VectorXd  b_k_beta,

            Eigen::MatrixXd  mu_var_DP,
            Eigen::VectorXd  nu_var_DP,
            Eigen::VectorXd  lambda_var_DP,
            std::vector<Eigen::MatrixXd>  PSI_var_DP_inv,

            Eigen::MatrixXd mu_VAR_MIX,
            Eigen::VectorXd nu_VAR_MIX,
            Eigen::VectorXd lambda_VAR_MIX,
            std::vector<Eigen::MatrixXd>  PSI_VAR_MIX_inv):

            Phi_m_k(Phi_m_k),  eta_k(eta_k) ,a_k_beta(a_k_beta), b_k_beta(b_k_beta),
            mu_var_DP(mu_var_DP),nu_var_DP(nu_var_DP), lambda_var_DP(lambda_var_DP),PSI_var_DP_inv(PSI_var_DP_inv),
            mu_VAR_MIX(mu_VAR_MIX),nu_VAR_MIX(nu_VAR_MIX), lambda_VAR_MIX(lambda_VAR_MIX), PSI_VAR_MIX_inv(PSI_VAR_MIX_inv){};


};


struct AlgorithmParameters{
public:
    unsigned p;
    unsigned J;
    unsigned T;

    unsigned n_iter;
    double tol;
    double gamma;

    Eigen::VectorXd a_dir_k;

    Eigen::VectorXd mu_0_DP;
    double nu_0_DP;
    double lambda_0_DP;
    Eigen::MatrixXd PSI_0_DP;

    Eigen::MatrixXd mu_0_MIX;
    Eigen::VectorXd nu_0_MIX;
    Eigen::VectorXd lambda_0_MIX;
    std::vector<Eigen::MatrixXd> PSI_0_MIX;

    unsigned M;

    AlgorithmParameters(const unsigned int p,
               const unsigned int J,
               const unsigned int T,

               const unsigned int n_iter,
               const double tol,
               const unsigned int gamma,

               Eigen::VectorXd a_dir_k,

               Eigen::VectorXd mu_0_DP,
               double nu_0_DP,
               double lambda_0_DP,
               Eigen::MatrixXd PSI_0_DP,

               Eigen::MatrixXd mu_0_MIX,
               Eigen::VectorXd nu_0_MIX,
               Eigen::VectorXd lambda_0_MIX,
               std::vector<Eigen::MatrixXd> PSI_0_MIX,

               const unsigned int M):
            p(p), J(J), T(T), n_iter(n_iter),tol(tol),gamma(gamma),a_dir_k(a_dir_k),
            mu_0_DP(mu_0_DP),nu_0_DP(nu_0_DP), lambda_0_DP(lambda_0_DP), PSI_0_DP(PSI_0_DP),
            mu_0_MIX(mu_0_MIX),nu_0_MIX(nu_0_MIX), lambda_0_MIX(lambda_0_MIX), PSI_0_MIX(PSI_0_MIX),
            M(M){};

    //StartingParameters(VBData & vb_data );
};

