//
// Created by DagiLeonardo on 30/03/2022.
//

#ifndef VARBRAND_H_ELBO_H
#define VARBRAND_H_ELBO_H

#include "VBData.h"
#include "Cavi.h"
#include "ELBO_functions.h"

#include <iostream>
#include <vector>
#include <tuple>

#include "root/lib/eigen-3.4.0/Eigen/Core"
#include "root/lib/eigen-3.4.0/Eigen/Dense"
#include "root/lib/eigen-3.4.0/Eigen/LU"
#include "root/lib/eigen-3.4.0/unsupported/Eigen/SpecialFunctions"

double elbo_calculator(const Eigen::MatrixXd&, VariationalParameters&, const AlgorithmParameters&,
                       std::vector<double>&);

#endif //VARBRAND_H_ELBO_H
